package com.example.flightreservation.controller;

import com.example.flightreservation.model.Passenger;
import com.example.flightreservation.repository.PassengerRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/passengers")
public class PassengerController {

    private final PassengerRepository passengerRepository;

    public PassengerController(PassengerRepository passengerRepository) {
        this.passengerRepository = passengerRepository;
    }

    @GetMapping
    public List<Passenger> passengerList() {
        return passengerRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Passenger> getPassengerById(@PathVariable Long id){
        return passengerRepository.findById(id).map(ResponseEntity::ok).
                orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Passenger> createPassenger(@Valid @RequestBody Passenger passenger) {
        Passenger saved = passengerRepository.save(passenger);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Passenger> updatePassanger(@PathVariable Long id, @Valid @RequestBody Passenger updated){
        return passengerRepository.findById(id)
                .map(passenger -> {
                    passenger.setFirstName(updated.getFirstName());
                    passenger.setLastName(updated.getLastName());
                    passenger.setEmail(updated.getEmail());
                    passenger.setPhone(updated.getPhone());
                    return ResponseEntity.ok(passengerRepository.save(passenger));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePassenger(@PathVariable Long id){
        if (!passengerRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        passengerRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

}
