package com.example.flightreservation.repository;

import com.example.flightreservation.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    long countByFlightId(Long flightId);

    boolean existsByFlightIdAndSeatNumber(Long flightId, String seatNumber);
}
