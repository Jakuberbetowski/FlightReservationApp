package com.example.flightreservation.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;


@Data
@Entity
public class Flight {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Origin cannot be empty")
    private String origin;

    @NotBlank(message = "Destination cannot be empty")
    private String destination;

    @Min(value = 1, message = "Flight duration must be at least 1 minute")
    private int duration;

    @NotBlank(message = "Flight number is required")
    private String flightNumber;


    private boolean roundTrip;   ;

    @Min(value = 1, message = "Capacity must be at least 1 seat")
    private int capacity;

    public Flight(Long id, String origin, String destination, int duration, String flightNumber, boolean roundTrip, int capacity) {
        this.id = id;
        this.origin = origin;
        this.destination = destination;
        this.duration = duration;
        this.flightNumber = flightNumber;
        this.roundTrip = roundTrip;
        this.capacity = capacity;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }

    public boolean isRoundTrip() { return roundTrip; }
    public void setRoundTrip(boolean roundTrip) { this.roundTrip = roundTrip; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
}
