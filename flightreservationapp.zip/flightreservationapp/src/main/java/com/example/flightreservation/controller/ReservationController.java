package com.example.flightreservation.controller;

import com.example.flightreservation.dto.ReservationRequest;
import com.example.flightreservation.model.Flight;
import com.example.flightreservation.model.Passenger;
import com.example.flightreservation.model.Reservation;
import com.example.flightreservation.repository.FlightRepository;
import com.example.flightreservation.repository.PassengerRepository;
import com.example.flightreservation.repository.ReservationRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/reservations")
@RequiredArgsConstructor
@Slf4j
public class ReservationController {

private final ReservationRepository reservationRepository;
private final PassengerRepository passengerRepository;
private final FlightRepository flightRepository;

    public ReservationController(ReservationRepository reservationRepository,
                                 FlightRepository flightRepository,
                                 PassengerRepository passengerRepository) {
        this.reservationRepository = reservationRepository;
        this.flightRepository = flightRepository;
        this.passengerRepository = passengerRepository;
    }

    @GetMapping
    public List<Reservation> getAllReservations(){
        return reservationRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reservation> getReservationById(@PathVariable Long id) {
        return reservationRepository.findById(id).
                map(ResponseEntity::ok).
                orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Reservation> createReservation(@Valid @RequestBody ReservationRequest request) {
        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Flight not found"));

        Passenger passenger = passengerRepository.findById(request.getPassengerId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Passenger not found"));

        if (reservationRepository.existsByFlightIdAndSeatNumber(flight.getId(), request.getSeatNumber())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Seat already taken");
        }

        long currentReservations = reservationRepository.countByFlightId(flight.getId());
        if (currentReservations >= flight.getCapacity()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No available seats on this flight");
        }

        Reservation reservation = new Reservation();
        reservation.setFlight(flight);
        reservation.setPassenger(passenger);
        reservation.setSeatNumber(request.getSeatNumber());
        reservation.setFlightCompleted(false);

        Reservation saved = reservationRepository.save(reservation);

        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Reservation> updateReservation(@PathVariable Long id,
                                                         @Valid @RequestBody ReservationRequest request) {
        return reservationRepository.findById(id)
                .map(reservation -> {
                    Flight newFlight = flightRepository.findById(request.getFlightId())
                            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Flight not found"));

                    Passenger newPassenger = passengerRepository.findById(request.getPassengerId())
                            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Passenger not found"));

                    if (!reservation.getFlight().getId().equals(newFlight.getId())
                            || !reservation.getSeatNumber().equals(request.getSeatNumber())) {

                        if (reservationRepository.existsByFlightIdAndSeatNumber(newFlight.getId(), request.getSeatNumber())) {
                            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Seat already taken");
                        }

                        long currentReservations = reservationRepository.countByFlightId(newFlight.getId());
                        if (!newFlight.getId().equals(reservation.getFlight().getId()) &&
                                currentReservations >= newFlight.getCapacity()) {
                            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "No available seats on this flight");
                        }
                    }

                    reservation.setFlight(newFlight);
                    reservation.setPassenger(newPassenger);
                    reservation.setSeatNumber(request.getSeatNumber());

                    return ResponseEntity.ok(reservationRepository.save(reservation));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReservation(@PathVariable Long id) {
        if (!reservationRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        reservationRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
