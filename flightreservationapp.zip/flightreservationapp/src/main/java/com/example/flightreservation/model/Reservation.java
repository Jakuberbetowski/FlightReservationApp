package com.example.flightreservation.model;

import jakarta.persistence.*;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Seat number is required")
    private String seatNumber;

    private boolean flightCompleted;

    @ManyToOne(optional = false)
    private Flight flight;

    @ManyToOne(optional = false)
    private Passenger passenger;

    public Reservation(){

    }

    public Reservation(Long id, String seatNumber, boolean flightCompleted, Flight flight, Passenger passenger) {
        this.id = id;
        this.seatNumber = seatNumber;
        this.flightCompleted = flightCompleted;
        this.flight = flight;
        this.passenger = passenger;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public boolean isFlightCompleted() { return flightCompleted; }
    public void setFlightCompleted(boolean flightCompleted) { this.flightCompleted = flightCompleted; }

    public Flight getFlight() { return flight; }
    public void setFlight(Flight flight) { this.flight = flight; }

    public Passenger getPassenger() { return passenger; }
    public void setPassenger(Passenger passenger) { this.passenger = passenger; }
}
