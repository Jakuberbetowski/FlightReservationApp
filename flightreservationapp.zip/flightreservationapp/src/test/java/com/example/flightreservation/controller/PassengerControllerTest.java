package com.example.flightreservation.controller;

import com.example.flightreservation.model.Passenger;
import com.example.flightreservation.repository.PassengerRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PassengerController.class)
public class PassengerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PassengerRepository passengerRepository;

    @Test
    public void testGetAllPassengers() throws Exception {
        Passenger p1 = new Passenger(1L, "Anna", "Kowalska", "anna@mail.com", "123456789");
        Passenger p2 = new Passenger(2L, "Jan", "Nowak", "jan@mail.com", "987654321");

        when(passengerRepository.findAll()).thenReturn(List.of(p1, p2));

        mockMvc.perform(get("/passengers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].firstName", is("Anna")))
                .andExpect(jsonPath("$[1].email", is("jan@mail.com")));
    }

    @Test
    public void testGetPassengerById_found() throws Exception {
        Passenger p1 = new Passenger(1L, "Anna", "Kowalska", "anna@mail.com", "123456789");
        when(passengerRepository.findById(1L)).thenReturn(Optional.of(p1));

        mockMvc.perform(get("/passengers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.lastName", is("Kowalska")));
    }

    @Test
    public void testGetPassengerById_notFound() throws Exception {
        when(passengerRepository.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/passengers/99"))
                .andExpect(status().isNotFound());
    }
}
