package com.example.flightreservation.controller;

import com.example.flightreservation.model.Flight;
import com.example.flightreservation.repository.FlightRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(FlightController.class)
public class FlightControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private FlightRepository flightRepository;

    @Test
    public void testGetAllFlights() throws Exception {
        Flight f1 = new Flight(1L, "Warszawa", "Londyn", 120, "LO123", false, 180);
        Flight f2 = new Flight(2L, "Berlin", "Paryż", 90, "AF456", true, 150);

        when(flightRepository.findAll()).thenReturn(List.of(f1, f2));

        mockMvc.perform(get("/flights"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].origin", is("Warszawa")))
                .andExpect(jsonPath("$[1].flightNumber", is("AF456")));
    }

    @Test
    public void testGetFlightById_found() throws Exception {
        Flight f1 = new Flight(1L, "Warszawa", "Londyn", 120, "LO123", false, 180);

        when(flightRepository.findById(1L)).thenReturn(Optional.of(f1));

        mockMvc.perform(get("/flights/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.destination", is("Londyn")));
    }

    @Test
    public void testGetFlightById_notFound() throws Exception {
        when(flightRepository.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/flights/99"))
                .andExpect(status().isNotFound());
    }
}
